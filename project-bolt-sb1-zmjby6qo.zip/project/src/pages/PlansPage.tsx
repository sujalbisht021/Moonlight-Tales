import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { Check, AlertCircle } from 'lucide-react';

const PlansPage: React.FC = () => {
  const { user } = useAuth();
  const { currentPlan, upgradeSubscription, isLoading } = useSubscription();

  const handleUpgrade = async (planType: 'lite' | 'pro') => {
    await upgradeSubscription(planType);
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-900 min-h-screen py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400">
            Select the perfect plan for your content creation needs
          </p>
        </div>

        {/* Current plan notification */}
        {user && (
          <div className="max-w-5xl mx-auto mb-12 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border-l-4 border-indigo-500">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-indigo-500" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                  Your current plan: <span className="font-bold capitalize">{currentPlan}</span>
                </h3>
                <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  <p>
                    {currentPlan === 'pro' 
                      ? 'You are currently on the Pro plan with up to 100 uploads.'
                      : 'You are currently on the Lite plan with up to 10 uploads.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Plans comparison */}
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
          {/* Lite plan */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
            <div className="p-8">
              <h3 className="text-2xl font-semibold text-gray-900 dark:text-white">Lite</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">Perfect for getting started</p>
              <p className="mt-6 flex items-baseline">
                <span className="text-4xl font-bold text-gray-900 dark:text-white">$5.99</span>
                <span className="ml-1 text-xl text-gray-500 dark:text-gray-400">/month</span>
              </p>
              <ul className="mt-8 space-y-4">
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Up to 10 uploads per month</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Basic AI caption generation</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">5 hashtags per upload</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Standard processing speed</span>
                </li>
              </ul>
              <div className="mt-8">
                {user ? (
                  currentPlan === 'lite' ? (
                    <span className="block w-full text-center rounded-md px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white font-medium">
                      Current Plan
                    </span>
                  ) : (
                    <button
                      onClick={() => handleUpgrade('lite')}
                      disabled={isLoading}
                      className="block w-full btn btn-outline"
                    >
                      {isLoading ? 'Processing...' : 'Switch to Lite'}
                    </button>
                  )
                ) : (
                  <Link to="/register" className="block w-full btn btn-outline">
                    Get Started
                  </Link>
                )}
              </div>
            </div>
          </div>

          {/* Pro plan */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden relative">
            <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
              <span className="bg-indigo-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                POPULAR
              </span>
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-semibold text-gray-900 dark:text-white">Pro</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">For power users</p>
              <p className="mt-6 flex items-baseline">
                <span className="text-4xl font-bold text-gray-900 dark:text-white">$9.99</span>
                <span className="ml-1 text-xl text-gray-500 dark:text-gray-400">/month</span>
              </p>
              <ul className="mt-8 space-y-4">
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Up to 100 uploads per month</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Advanced AI caption generation</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">10+ hashtags per upload</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Priority processing</span>
                </li>
                <li className="flex items-center">
                  <Check className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-700 dark:text-gray-300">Advanced analytics</span>
                </li>
              </ul>
              <div className="mt-8">
                {user ? (
                  currentPlan === 'pro' ? (
                    <span className="block w-full text-center rounded-md px-4 py-2 bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200 font-medium">
                      Current Plan
                    </span>
                  ) : (
                    <button
                      onClick={() => handleUpgrade('pro')}
                      disabled={isLoading}
                      className="block w-full btn btn-primary"
                    >
                      {isLoading ? 'Processing...' : 'Upgrade to Pro'}
                    </button>
                  )
                ) : (
                  <Link to="/register" className="block w-full btn btn-primary">
                    Get Started
                  </Link>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlansPage;