import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSubscription } from '../contexts/SubscriptionContext';
import { supabase } from '../lib/supabase';
import { Upload, ArrowRight, ChevronUp, ChevronDown, Image, Video, Calendar } from 'lucide-react';
import { format } from 'date-fns';

type UploadItem = {
  id: string;
  file_name: string;
  file_type: string;
  created_at: string;
  status: string;
};

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { currentPlan, remainingUploads } = useSubscription();
  const [recentUploads, setRecentUploads] = useState<UploadItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [statsExpanded, setStatsExpanded] = useState(true);
  
  useEffect(() => {
    const fetchUploads = async () => {
      if (!user) return;
      
      setLoading(true);
      try {
        // In a real app, fetch uploads from the database
        const { data, error } = await supabase
          .from('uploads')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(10);
        
        if (error) throw error;
        
        // If no actual data, create dummy data for the demo
        if (!data || data.length === 0) {
          const dummyData: UploadItem[] = [
            {
              id: '1',
              file_name: 'mountain_landscape.jpg',
              file_type: 'image/jpeg',
              created_at: new Date().toISOString(),
              status: 'completed',
            },
            {
              id: '2',
              file_name: 'hiking_trail.mp4',
              file_type: 'video/mp4',
              created_at: new Date(Date.now() - 86400000).toISOString(), // Yesterday
              status: 'completed',
            },
            {
              id: '3',
              file_name: 'beach_sunset.jpg',
              file_type: 'image/jpeg',
              created_at: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
              status: 'completed',
            },
          ];
          
          setRecentUploads(dummyData);
        } else {
          setRecentUploads(data);
        }
      } catch (error) {
        console.error('Error fetching uploads:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchUploads();
  }, [user]);

  const toggleStats = () => {
    setStatsExpanded(!statsExpanded);
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4 md:mb-0">
            Dashboard
          </h1>
          <Link
            to="/upload"
            className="btn btn-primary"
          >
            <Upload className="h-5 w-5 mr-2" />
            Upload New
          </Link>
        </div>
        
        {/* Stats cards */}
        <div className="mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
            <div 
              className="px-6 py-4 flex justify-between items-center cursor-pointer"
              onClick={toggleStats}
            >
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Account Overview
              </h2>
              <button className="text-gray-500 dark:text-gray-400">
                {statsExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
            </div>
            
            {statsExpanded && (
              <div className="px-6 pb-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
                  {/* Plan card */}
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Current Plan</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                          {currentPlan === 'pro' ? 'Pro' : 'Free'}
                        </p>
                      </div>
                      {currentPlan === 'pro' ? (
                        <span className="bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300 px-2 py-1 rounded-md text-xs font-semibold">
                          UNLIMITED
                        </span>
                      ) : (
                        <Link to="/plans" className="text-indigo-600 dark:text-indigo-400 text-sm font-medium">
                          Upgrade
                        </Link>
                      )}
                    </div>
                    {currentPlan === 'free' && (
                      <div className="mt-4">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-500 dark:text-gray-400">
                            Uploads remaining
                          </span>
                          <span className="text-gray-900 dark:text-white font-medium">
                            {remainingUploads}/3
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div 
                            className="bg-indigo-600 h-2 rounded-full"
                            style={{ width: `${(remainingUploads / 3) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Uploads card */}
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Total Uploads</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                      {recentUploads.length}
                    </p>
                    <div className="mt-4 flex items-end justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center text-sm">
                          <span className="w-3 h-3 rounded-full bg-indigo-500 mr-2"></span>
                          <span className="text-gray-500 dark:text-gray-400">Images</span>
                        </div>
                        <div className="flex items-center text-sm">
                          <span className="w-3 h-3 rounded-full bg-purple-500 mr-2"></span>
                          <span className="text-gray-500 dark:text-gray-400">Videos</span>
                        </div>
                      </div>
                      <div className="flex h-12 items-end space-x-1">
                        <div className="w-5 bg-indigo-500 rounded-t-sm" style={{ height: '60%' }}></div>
                        <div className="w-5 bg-indigo-500 rounded-t-sm" style={{ height: '80%' }}></div>
                        <div className="w-5 bg-indigo-500 rounded-t-sm" style={{ height: '40%' }}></div>
                        <div className="w-5 bg-purple-500 rounded-t-sm" style={{ height: '30%' }}></div>
                        <div className="w-5 bg-purple-500 rounded-t-sm" style={{ height: '50%' }}></div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Activity card */}
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Recent Activity</p>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                      {recentUploads.length > 0 
                        ? format(new Date(recentUploads[0].created_at), 'MMM d, yyyy') 
                        : 'No activity'}
                    </p>
                    <div className="mt-4 text-sm text-gray-500 dark:text-gray-400">
                      <div className="flex items-center justify-between">
                        <span>Last upload:</span>
                        <span className="text-gray-900 dark:text-white">
                          {recentUploads.length > 0 
                            ? format(new Date(recentUploads[0].created_at), 'h:mm a') 
                            : '-'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <span>File type:</span>
                        <span className="text-gray-900 dark:text-white">
                          {recentUploads.length > 0 
                            ? (recentUploads[0].file_type.includes('image') ? 'Image' : 'Video') 
                            : '-'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Recent uploads */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Recent Uploads
            </h2>
          </div>
          
          {loading ? (
            <div className="p-8 flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-4 border-indigo-500 border-t-transparent"></div>
            </div>
          ) : recentUploads.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <div className="mb-4 flex justify-center">
                <Upload className="h-12 w-12 text-gray-400 dark:text-gray-600" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                No uploads yet
              </h3>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                Get started by uploading your first photo or video
              </p>
              <Link to="/upload" className="btn btn-primary">
                Upload Media
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-900">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      File
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {recentUploads.map((upload) => (
                    <tr key={upload.id} className="hover:bg-gray-50 dark:hover:bg-gray-900/50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center">
                            {upload.file_type.startsWith('image/') ? (
                              <Image className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                            ) : (
                              <Video className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                            )}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                              {upload.file_name}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {upload.file_type.split('/')[0]}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                          <Calendar className="h-4 w-4 mr-1.5" />
                          {format(new Date(upload.created_at), 'MMM d, yyyy')}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          upload.status === 'completed' 
                            ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                            : upload.status === 'processing'
                            ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                        }`}>
                          {upload.status === 'completed' ? 'Completed' : upload.status === 'processing' ? 'Processing' : 'Failed'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <Link 
                          to={`/results/${upload.id}`} 
                          className="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 inline-flex items-center"
                        >
                          View
                          <ArrowRight className="ml-1 h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          
          {recentUploads.length > 0 && (
            <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700 flex justify-between items-center">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Showing {recentUploads.length} recent uploads
              </p>
              <button className="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 text-sm font-medium">
                View All
              </button>
            </div>
          )}
        </div>

        {/* Upgrade banner (for free users) */}
        {currentPlan === 'free' && (
          <div className="mt-8">
            <div className="bg-indigo-600 rounded-lg shadow-lg overflow-hidden">
              <div className="px-6 py-8 md:p-10 lg:py-12 flex flex-col md:flex-row items-center">
                <div className="md:w-2/3 mb-6 md:mb-0">
                  <h3 className="text-xl md:text-2xl font-bold text-white">
                    Upgrade to Pro and unlock unlimited uploads!
                  </h3>
                  <p className="mt-2 text-indigo-100">
                    Get advanced AI captions, more hashtags, and premium SEO descriptions.
                  </p>
                </div>
                <div className="md:w-1/3 flex justify-center md:justify-end">
                  <Link to="/plans" className="btn bg-white text-indigo-600 hover:bg-indigo-50">
                    Upgrade Now
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;