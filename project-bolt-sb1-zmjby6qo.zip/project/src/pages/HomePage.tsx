import React from 'react';
import { Link } from 'react-router-dom';
import { Upload, MessageSquare, Hash, Search, ArrowRight, Check } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="w-full">
      {/* Hero section */}
      <section className="relative py-20 md:py-32 overflow-hidden bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-5"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              AI-Powered <span className="text-indigo-600 dark:text-indigo-400">Captions</span> for Your Content
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-10 leading-relaxed">
              Transform your photos and videos into engagement-driving content with AI generated captions, hashtags, and SEO descriptions.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                to="/register"
                className="btn btn-primary text-base sm:text-lg px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
              >
                Get Started Free
              </Link>
              <Link
                to="/plans"
                className="btn btn-outline text-base sm:text-lg px-8 py-3 rounded-lg"
              >
                View Pricing
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              How CaptionAI Works
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Our AI-powered platform makes it easy to create engaging content for social media.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="card dark:bg-gray-800 p-8 text-center">
              <div className="flex justify-center mb-6">
                <div className="rounded-full bg-indigo-100 dark:bg-indigo-900/30 p-4">
                  <Upload className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                Upload Media
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Upload your photos or videos to our secure platform with just a few clicks.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="card dark:bg-gray-800 p-8 text-center">
              <div className="flex justify-center mb-6">
                <div className="rounded-full bg-indigo-100 dark:bg-indigo-900/30 p-4">
                  <MessageSquare className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                Generate Content
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Our AI analyzes your media and generates engaging captions and hashtags.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="card dark:bg-gray-800 p-8 text-center">
              <div className="flex justify-center mb-6">
                <div className="rounded-full bg-indigo-100 dark:bg-indigo-900/30 p-4">
                  <Search className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
                Boost Visibility
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                Improve your content's SEO with optimized descriptions and relevant hashtags.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Example output section */}
      <section className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              See CaptionAI in Action
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Here's an example of what our AI can generate for your content.
            </p>
          </div>

          <div className="max-w-5xl mx-auto bg-white dark:bg-gray-900 rounded-xl shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img
                  src="https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="Mountain landscape"
                  className="w-full h-72 md:h-full object-cover"
                />
              </div>
              <div className="p-8 md:w-1/2">
                <div className="mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    AI-Generated Caption
                  </h3>
                  <p className="text-gray-700 dark:text-gray-300 font-medium">
                    "Finding peace in the mountains, where the air is clean and the views are breathtaking. Nature's therapy at its finest. ✨🏔️"
                  </p>
                </div>

                <div className="mb-6">
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    Hashtags
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {['#mountainviews', '#naturelovers', '#outdooradventures', '#wanderlust', '#landscapephotography', '#travelgram', '#hikingadventures', '#exploremore'].map((tag) => (
                      <span key={tag} className="bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300 px-3 py-1 rounded-full text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    SEO Description
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    Explore the majestic mountain landscapes captured in this stunning photograph. Perfect for nature enthusiasts, hikers, and adventure seekers looking for inspiration. This image showcases the breathtaking views, serene atmosphere, and natural beauty of mountain ranges, ideal for travel blogs, outdoor activity websites, or nature conservation content.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing section */}
      <section className="py-20 bg-white dark:bg-gray-900">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Choose the plan that's right for you
            </p>
          </div>

          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
            {/* Free plan */}
            <div className="card dark:bg-gray-800 p-8">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                Free
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Perfect for getting started
              </p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-gray-900 dark:text-white">$0</span>
                <span className="text-gray-600 dark:text-gray-400">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span className="text-gray-600 dark:text-gray-300">3 uploads per month</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span className="text-gray-600 dark:text-gray-300">Basic AI caption generation</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span className="text-gray-600 dark:text-gray-300">5 hashtags per upload</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                  <span className="text-gray-600 dark:text-gray-300">Basic SEO description</span>
                </li>
              </ul>
              <Link to="/register" className="btn btn-outline w-full">
                Get Started
              </Link>
            </div>

            {/* Pro plan */}
            <div className="card bg-indigo-600 text-white p-8 transform md:scale-105 shadow-xl">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-bold mb-2">
                    Pro
                  </h3>
                  <p className="text-indigo-200 mb-6">
                    For content creators and professionals
                  </p>
                </div>
                <span className="bg-white text-indigo-600 px-3 py-1 rounded-full text-xs font-semibold">
                  POPULAR
                </span>
              </div>
              <div className="mb-6">
                <span className="text-4xl font-bold">$9.99</span>
                <span className="text-indigo-200">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-indigo-300 mr-2 mt-0.5" />
                  <span className="text-white">Unlimited uploads</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-indigo-300 mr-2 mt-0.5" />
                  <span className="text-white">Advanced AI caption generation</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-indigo-300 mr-2 mt-0.5" />
                  <span className="text-white">10+ hashtags per upload</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-indigo-300 mr-2 mt-0.5" />
                  <span className="text-white">Premium SEO optimization</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-indigo-300 mr-2 mt-0.5" />
                  <span className="text-white">Priority processing</span>
                </li>
                <li className="flex items-start">
                  <Check className="h-5 w-5 text-indigo-300 mr-2 mt-0.5" />
                  <span className="text-white">Download history and analytics</span>
                </li>
              </ul>
              <Link to="/register" className="btn w-full bg-white text-indigo-600 hover:bg-indigo-50">
                Start Pro Plan
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA section */}
      <section className="py-20 bg-indigo-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Boost Your Content's Engagement?
            </h2>
            <p className="text-xl text-indigo-200 mb-10">
              Join thousands of content creators who are already using CaptionAI to enhance their social media presence.
            </p>
            <Link
              to="/register"
              className="inline-flex items-center bg-white text-indigo-600 hover:bg-indigo-50 px-8 py-3 rounded-lg text-lg font-medium shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Get Started Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;