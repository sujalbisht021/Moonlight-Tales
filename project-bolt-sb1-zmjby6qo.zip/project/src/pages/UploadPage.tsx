import React from 'react';
import UploadForm from '../components/upload/UploadForm';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const UploadPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <Link 
          to="/dashboard" 
          className="inline-flex items-center text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 mb-8"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </Link>
        
        <UploadForm />
      </div>
    </div>
  );
};

export default UploadPage;