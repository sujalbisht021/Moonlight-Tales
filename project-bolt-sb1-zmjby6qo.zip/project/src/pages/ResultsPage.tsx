import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Copy, CheckCircle, Image, Video, Download, Share2 } from 'lucide-react';
import { toast } from 'react-toastify';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

type GeneratedContent = {
  caption: string;
  hashtags: string[];
  seoDescription: string;
};

const ResultsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [uploadData, setUploadData] = useState<any>(null);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent | null>(null);
  const [copyStatus, setCopyStatus] = useState({
    caption: false,
    hashtags: false,
    seoDescription: false,
  });

  useEffect(() => {
    const fetchResults = async () => {
      if (!id || !user) return;
      
      setLoading(true);
      
      try {
        // In a real app, fetch the upload data from your database
        const { data, error } = await supabase
          .from('uploads')
          .select('*')
          .eq('id', id)
          .eq('user_id', user.id)
          .single();
        
        if (error) throw error;
        
        setUploadData(data);
        
        // In a real app, the AI-generated content would be stored in the database
        // For this demo, we'll simulate the generated content
        
        // Simulate some processing time
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Simulate AI-generated content based on file type
        const isImage = data.file_type.startsWith('image/');
        
        const content: GeneratedContent = {
          caption: isImage
            ? "Finding peace in the mountains, where the air is clean and the views are breathtaking. Nature's therapy at its finest. ✨🏔️"
            : "Exploring new trails and pushing my limits with every step. The journey is always worth it when views like this await at the top! 🌄 #AdventureTime",
          hashtags: [
            "#naturelovers",
            "#mountainviews",
            "#outdooradventures",
            "#wanderlust",
            "#landscapephotography",
            "#travelgram",
            "#hikingadventures",
            "#exploremore",
            "#naturephotography",
            "#wildernessculture"
          ],
          seoDescription: isImage
            ? "Majestic mountain landscape photograph showcasing breathtaking views of snow-capped peaks under clear blue skies. Perfect for nature enthusiasts, hikers, and adventure seekers looking for inspiration. This high-quality image captures the serenity and grandeur of mountain ranges, ideal for travel blogs, outdoor activity websites, or conservation content featuring wilderness destinations."
            : "Immersive video footage of a scenic mountain hiking trail featuring diverse landscapes from lush forests to panoramic summit views. This content captures the authentic experience of outdoor adventure, making it perfect for travel blogs, hiking guides, and outdoor recreation platforms. The video showcases natural beauty and wilderness exploration, appealing to adventure travelers and nature enthusiasts seeking new destinations."
        };
        
        setGeneratedContent(content);
      } catch (error) {
        console.error('Error fetching results:', error);
        toast.error('Failed to load results. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchResults();
  }, [id, user]);

  const handleCopy = (type: 'caption' | 'hashtags' | 'seoDescription') => {
    if (!generatedContent) return;
    
    let textToCopy = '';
    
    switch (type) {
      case 'caption':
        textToCopy = generatedContent.caption;
        break;
      case 'hashtags':
        textToCopy = generatedContent.hashtags.join(' ');
        break;
      case 'seoDescription':
        textToCopy = generatedContent.seoDescription;
        break;
    }
    
    navigator.clipboard.writeText(textToCopy).then(() => {
      // Set the copy status for this field to true
      setCopyStatus(prev => ({ ...prev, [type]: true }));
      
      // Reset the copy status after 2 seconds
      setTimeout(() => {
        setCopyStatus(prev => ({ ...prev, [type]: false }));
      }, 2000);
      
      toast.success('Copied to clipboard!');
    }).catch(() => {
      toast.error('Failed to copy to clipboard.');
    });
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <Link 
          to="/dashboard" 
          className="inline-flex items-center text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 mb-8"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </Link>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              AI-Generated Content
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Review and copy the generated content for your media
            </p>
          </div>
          
          {loading ? (
            <div className="p-12 flex justify-center items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
            </div>
          ) : (
            <div className="p-6">
              <div className="flex flex-col lg:flex-row gap-8">
                {/* Media preview */}
                <div className="lg:w-1/3">
                  <div className="bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden" style={{ height: '240px' }}>
                    {uploadData?.file_type?.startsWith('image/') ? (
                      // In a real app, this would be the actual image
                      <div className="w-full h-full flex items-center justify-center">
                        <img 
                          src="https://images.pexels.com/photos/2253275/pexels-photo-2253275.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                          alt="Uploaded content"
                          className="w-full h-full object-contain" 
                        />
                      </div>
                    ) : (
                      // For video, we could show a player, but for now just show an icon
                      <div className="w-full h-full flex flex-col items-center justify-center">
                        {uploadData?.file_type === 'video/mp4' ? (
                          <>
                            <Video className="h-16 w-16 text-gray-500 dark:text-gray-400" />
                            <span className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                              Video file
                            </span>
                          </>
                        ) : (
                          <>
                            <Image className="h-16 w-16 text-gray-500 dark:text-gray-400" />
                            <span className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                              Image file
                            </span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex justify-between mb-1">
                      <span>File name:</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {uploadData?.file_name || 'Unknown'}
                      </span>
                    </div>
                    <div className="flex justify-between mb-1">
                      <span>File type:</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {uploadData?.file_type || 'Unknown'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Uploaded:</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {uploadData?.created_at 
                          ? new Date(uploadData.created_at).toLocaleDateString() 
                          : 'Unknown'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-6 flex gap-2">
                    <button className="btn btn-outline text-sm flex-1 py-1.5">
                      <Download className="h-4 w-4 mr-1.5" />
                      Download
                    </button>
                    <button className="btn btn-outline text-sm flex-1 py-1.5">
                      <Share2 className="h-4 w-4 mr-1.5" />
                      Share
                    </button>
                  </div>
                </div>
                
                {/* Generated content */}
                <div className="lg:w-2/3 space-y-6">
                  {/* Caption */}
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        Caption
                      </h3>
                      <button 
                        onClick={() => handleCopy('caption')}
                        className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center text-sm"
                      >
                        {copyStatus.caption ? (
                          <>
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4 mr-1" />
                            Copy
                          </>
                        )}
                      </button>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300">
                      {generatedContent?.caption}
                    </p>
                  </div>
                  
                  {/* Hashtags */}
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        Hashtags
                      </h3>
                      <button 
                        onClick={() => handleCopy('hashtags')}
                        className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center text-sm"
                      >
                        {copyStatus.hashtags ? (
                          <>
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4 mr-1" />
                            Copy
                          </>
                        )}
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {generatedContent?.hashtags.map((tag, index) => (
                        <span 
                          key={index} 
                          className="bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300 px-3 py-1 rounded-full text-sm"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  {/* SEO Description */}
                  <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        SEO Description
                      </h3>
                      <button 
                        onClick={() => handleCopy('seoDescription')}
                        className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center text-sm"
                      >
                        {copyStatus.seoDescription ? (
                          <>
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4 mr-1" />
                            Copy
                          </>
                        )}
                      </button>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300 text-sm">
                      {generatedContent?.seoDescription}
                    </p>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="mt-8 flex flex-col sm:flex-row gap-4 border-t border-gray-200 dark:border-gray-700 pt-6">
                <Link to="/upload" className="btn btn-primary flex-1">
                  Upload Another
                </Link>
                <Link to="/dashboard" className="btn btn-outline flex-1">
                  Return to Dashboard
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;