import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { User, Settings, Users, FileVideo, FileImage, BarChart, DollarSign, Calendar } from 'lucide-react';

// Sample data types
type UserStats = {
  total: number;
  active: number;
  free: number;
  pro: number;
};

type UploadStats = {
  total: number;
  images: number;
  videos: number;
  averagePerUser: number;
};

type RevenueStats = {
  total: string;
  monthly: string;
  annual: string;
  averagePerUser: string;
};

const AdminPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userStats, setUserStats] = useState<UserStats>({
    total: 0,
    active: 0,
    free: 0,
    pro: 0,
  });
  const [uploadStats, setUploadStats] = useState<UploadStats>({
    total: 0,
    images: 0,
    videos: 0,
    averagePerUser: 0,
  });
  const [revenueStats, setRevenueStats] = useState<RevenueStats>({
    total: '$0',
    monthly: '$0',
    annual: '$0',
    averagePerUser: '$0',
  });
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    const fetchAdminData = async () => {
      setLoading(true);
      
      try {
        // In a real app, fetch this data from your database
        // For the demo, we'll use mock data
        
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // User stats
        setUserStats({
          total: 251,
          active: 189,
          free: 176,
          pro: 75,
        });
        
        // Upload stats
        setUploadStats({
          total: 1234,
          images: 890,
          videos: 344,
          averagePerUser: 4.9,
        });
        
        // Revenue stats
        setRevenueStats({
          total: '$7,425.50',
          monthly: '$4,295.75',
          annual: '$3,129.75',
          averagePerUser: '$29.58',
        });
        
        // Users
        const mockUsers = [
          {
            id: '1',
            email: 'sarah@example.com',
            name: 'Sarah Johnson',
            plan: 'pro',
            uploads: 42,
            subscribed_since: '2023-11-15',
          },
          {
            id: '2',
            email: 'michael@example.com',
            name: 'Michael Smith',
            plan: 'free',
            uploads: 3,
            subscribed_since: '2024-01-08',
          },
          {
            id: '3',
            email: 'jessica@example.com',
            name: 'Jessica Williams',
            plan: 'pro',
            uploads: 28,
            subscribed_since: '2023-10-22',
          },
          {
            id: '4',
            email: 'david@example.com',
            name: 'David Brown',
            plan: 'free',
            uploads: 2,
            subscribed_since: '2024-02-05',
          },
          {
            id: '5',
            email: 'emily@example.com',
            name: 'Emily Davis',
            plan: 'pro',
            uploads: 56,
            subscribed_since: '2023-09-18',
          },
        ];
        
        setUsers(mockUsers);
      } catch (error) {
        console.error('Error fetching admin data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchAdminData();
  }, []);

  const renderDashboard = () => (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        Admin Dashboard
      </h1>
      
      {/* Overview cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Users card */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex items-center">
              <div className="bg-indigo-100 dark:bg-indigo-900/30 p-3 rounded-full">
                <Users className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Total Users
                </h3>
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  {userStats.total}
                </span>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Active</span>
                <span className="text-gray-900 dark:text-white font-medium">{userStats.active}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Pro</span>
                <span className="text-gray-900 dark:text-white font-medium">{userStats.pro}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Free</span>
                <span className="text-gray-900 dark:text-white font-medium">{userStats.free}</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-3">
                <div 
                  className="bg-indigo-600 h-2 rounded-full"
                  style={{ width: `${(userStats.pro / userStats.total) * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {Math.round((userStats.pro / userStats.total) * 100)}% Pro users
              </p>
            </div>
          </div>
        </div>
        
        {/* Uploads card */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex items-center">
              <div className="bg-purple-100 dark:bg-purple-900/30 p-3 rounded-full">
                <FileImage className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Total Uploads
                </h3>
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  {uploadStats.total}
                </span>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Images</span>
                <span className="text-gray-900 dark:text-white font-medium">{uploadStats.images}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Videos</span>
                <span className="text-gray-900 dark:text-white font-medium">{uploadStats.videos}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Avg. per user</span>
                <span className="text-gray-900 dark:text-white font-medium">{uploadStats.averagePerUser}</span>
              </div>
              <div className="flex h-10 items-end space-x-1 mt-3">
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '40%' }}></div>
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '60%' }}></div>
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '80%' }}></div>
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '50%' }}></div>
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '70%' }}></div>
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '90%' }}></div>
                <div className="flex-1 bg-purple-500 rounded-t-sm" style={{ height: '65%' }}></div>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Last 7 days
              </p>
            </div>
          </div>
        </div>
        
        {/* Revenue card */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex items-center">
              <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Revenue
                </h3>
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  {revenueStats.total}
                </span>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Monthly plans</span>
                <span className="text-gray-900 dark:text-white font-medium">{revenueStats.monthly}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Annual plans</span>
                <span className="text-gray-900 dark:text-white font-medium">{revenueStats.annual}</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Avg. per user</span>
                <span className="text-gray-900 dark:text-white font-medium">{revenueStats.averagePerUser}</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-3">
                <div 
                  className="bg-green-500 h-2 rounded-full"
                  style={{ width: '58%' }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                58% Monthly recurring revenue
              </p>
            </div>
          </div>
        </div>
        
        {/* Active now card */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
          <div className="p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-full">
                <BarChart className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">
                  Active Now
                </h3>
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  14
                </span>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">Uploading</span>
                <span className="text-gray-900 dark:text-white font-medium">3</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Viewing results</span>
                <span className="text-gray-900 dark:text-white font-medium">7</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span className="text-gray-500 dark:text-gray-400">Browsing</span>
                <span className="text-gray-900 dark:text-white font-medium">4</span>
              </div>
              <div className="mt-3 flex items-center">
                <div className="relative">
                  <div className="flex -space-x-2">
                    <div className="w-6 h-6 rounded-full bg-indigo-500 flex items-center justify-center text-xs text-white">S</div>
                    <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center text-xs text-white">M</div>
                    <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center text-xs text-white">J</div>
                    <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center text-xs text-white">D</div>
                  </div>
                </div>
                <div className="ml-2 text-xs text-gray-500 dark:text-gray-400">
                  +10 more
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recent users */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Recent Users
          </h2>
          <button
            onClick={() => setActiveTab('users')}
            className="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 text-sm font-medium"
          >
            View All
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  User
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Plan
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Uploads
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Joined
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {users.slice(0, 5).map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-900/50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center">
                        <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                          {user.name.charAt(0)}
                        </span>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {user.name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {user.email}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      user.plan === 'pro' 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {user.plan === 'pro' ? 'Pro' : 'Free'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white">{user.uploads}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {new Date(user.subscribed_since).toLocaleDateString()}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        User Management
      </h1>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              All Users
            </h2>
            <div className="relative">
              <input
                type="search"
                className="input py-1 pl-8 pr-3 text-sm"
                placeholder="Search users..."
              />
              <div className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none">
                <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  User
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Plan
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Uploads
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Joined
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-900/50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center">
                        <span className="text-indigo-600 dark:text-indigo-400 font-medium">
                          {user.name.charAt(0)}
                        </span>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {user.name}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {user.email}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      user.plan === 'pro' 
                        ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' 
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {user.plan === 'pro' ? 'Pro' : 'Free'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900 dark:text-white">{user.uploads}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {new Date(user.subscribed_since).toLocaleDateString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300 mr-4">
                      Edit
                    </button>
                    <button className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Showing <span className="font-medium">1</span> to <span className="font-medium">5</span> of <span className="font-medium">{userStats.total}</span> users
          </div>
          <div className="flex items-center space-x-2">
            <button className="btn btn-outline py-1 px-3 text-sm">
              Previous
            </button>
            <button className="btn btn-primary py-1 px-3 text-sm">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
        System Settings
      </h1>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Plan Settings
          </h2>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Free plan settings */}
          <div className="space-y-4">
            <h3 className="text-md font-medium text-gray-900 dark:text-white">
              Free Plan Limits
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="free-uploads" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Monthly uploads
                </label>
                <input
                  type="number"
                  id="free-uploads"
                  className="mt-1 input"
                  value="3"
                />
              </div>
              
              <div>
                <label htmlFor="free-hashtags" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Hashtags per upload
                </label>
                <input
                  type="number"
                  id="free-hashtags"
                  className="mt-1 input"
                  value="5"
                />
              </div>
            </div>
          </div>
          
          {/* Pro plan settings */}
          <div className="space-y-4 pt-6 border-t border-gray-200 dark:border-gray-700">
            <h3 className="text-md font-medium text-gray-900 dark:text-white">
              Pro Plan Settings
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="pro-price" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Monthly price ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  id="pro-price"
                  className="mt-1 input"
                  value="9.99"
                />
              </div>
              
              <div>
                <label htmlFor="pro-hashtags" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Hashtags per upload
                </label>
                <input
                  type="number"
                  id="pro-hashtags"
                  className="mt-1 input"
                  value="10"
                />
              </div>
            </div>
          </div>
          
          {/* AI settings */}
          <div className="space-y-4 pt-6 border-t border-gray-200 dark:border-gray-700">
            <h3 className="text-md font-medium text-gray-900 dark:text-white">
              AI Settings
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="ai-model" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Model
                </label>
                <select
                  id="ai-model"
                  className="mt-1 input"
                >
                  <option>GPT-4</option>
                  <option>GPT-3.5 Turbo</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="caption-length" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                  Caption length (characters)
                </label>
                <input
                  type="number"
                  id="caption-length"
                  className="mt-1 input"
                  value="200"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="system-prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                System prompt
              </label>
              <textarea
                id="system-prompt"
                rows={4}
                className="mt-1 input"
                value="You are a social media assistant that creates engaging captions, relevant hashtags, and SEO-optimized descriptions for user-uploaded media."
              ></textarea>
            </div>
          </div>
          
          <div className="flex justify-end pt-6 border-t border-gray-200 dark:border-gray-700">
            <button className="btn btn-primary">
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:space-x-8">
        {/* Sidebar */}
        <div className="w-full md:w-64 mb-8 md:mb-0">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                Admin Panel
              </h2>
            </div>
            <nav className="p-4">
              <ul className="space-y-2">
                <li>
                  <button
                    onClick={() => setActiveTab('dashboard')}
                    className={`w-full flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeTab === 'dashboard'
                        ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    }`}
                  >
                    <BarChart className="h-5 w-5 mr-3" />
                    Dashboard
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab('users')}
                    className={`w-full flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeTab === 'users'
                        ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    }`}
                  >
                    <Users className="h-5 w-5 mr-3" />
                    Users
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => setActiveTab('settings')}
                    className={`w-full flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeTab === 'settings'
                        ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    }`}
                  >
                    <Settings className="h-5 w-5 mr-3" />
                    Settings
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-4 border-indigo-500 border-t-transparent"></div>
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && renderDashboard()}
              {activeTab === 'users' && renderUsers()}
              {activeTab === 'settings' && renderSettings()}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPage;