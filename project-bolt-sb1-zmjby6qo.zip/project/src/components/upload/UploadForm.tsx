import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useNavigate } from 'react-router-dom';
import { Upload, Image, Video, File, X, Loader } from 'lucide-react';
import { toast } from 'react-toastify';
import { useSubscription } from '../../contexts/SubscriptionContext';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
const ACCEPTED_FILE_TYPES = {
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
  'video/mp4': ['.mp4'],
};

const UploadForm: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { user } = useAuth();
  const { remainingUploads, currentPlan, refreshSubscription } = useSubscription();
  const navigate = useNavigate();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const selectedFile = acceptedFiles[0];
      
      // Check file size
      if (selectedFile.size > MAX_FILE_SIZE) {
        toast.error(`File too large. Maximum size is ${MAX_FILE_SIZE / (1024 * 1024)}MB`);
        return;
      }
      
      setFile(selectedFile);
      
      // Create preview
      if (selectedFile.type.startsWith('image/')) {
        const objectUrl = URL.createObjectURL(selectedFile);
        setPreview(objectUrl);
      } else if (selectedFile.type === 'video/mp4') {
        // For video, we could create a thumbnail, but for now just show an icon
        setPreview(null);
      }
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ACCEPTED_FILE_TYPES,
    maxFiles: 1,
  });

  const clearSelectedFile = () => {
    if (preview) {
      URL.revokeObjectURL(preview);
    }
    setFile(null);
    setPreview(null);
  };

  const handleUpload = async () => {
    if (!file || !user) return;
    
    // Check if user has uploads remaining on free plan
    if (currentPlan === 'free' && remainingUploads <= 0) {
      toast.error('You have reached your monthly upload limit. Upgrade to Pro for unlimited uploads.');
      return;
    }
    
    setUploading(true);
    setUploadProgress(0);
    
    try {
      // In a real app, this would upload to storage like S3 or Firebase
      // For this demo, we'll simulate the upload process
      const fileName = `${Date.now()}-${file.name}`;
      const filePath = `uploads/${user.id}/${fileName}`;
      
      // Simulate progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 95) {
            clearInterval(interval);
            return 95;
          }
          return prev + 5;
        });
      }, 300);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Clear interval and set progress to 100
      clearInterval(interval);
      setUploadProgress(100);
      
      // In a real app, you would get back the URL of the uploaded file
      const fileUrl = `https://example.com/${filePath}`;
      
      // Create a record in the database
      const { data: uploadData, error: uploadError } = await supabase
        .from('uploads')
        .insert({
          user_id: user.id,
          file_name: fileName,
          file_path: filePath,
          file_type: file.type,
          file_size: file.size,
          status: 'processing',
        })
        .select()
        .single();
      
      if (uploadError) throw uploadError;
      
      // Refresh subscription to update remaining uploads
      await refreshSubscription();
      
      // In a real app, you would trigger AI processing here
      // For this demo, we'll simulate the processing by directly navigating to results
      
      toast.success('File uploaded successfully!');
      
      // Navigate to the results page
      navigate(`/results/${uploadData.id}`);
    } catch (error: any) {
      console.error('Error uploading file:', error);
      toast.error(error.message || 'Failed to upload file. Please try again.');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Upload Media</h2>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          {currentPlan === 'free' 
            ? `${remainingUploads} uploads remaining this month` 
            : 'Unlimited uploads available'}
        </p>
      </div>
      
      {!file ? (
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
            isDragActive 
              ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/10' 
              : 'border-gray-300 dark:border-gray-700 hover:border-indigo-300 dark:hover:border-indigo-700'
          }`}
        >
          <input {...getInputProps()} />
          <div className="flex flex-col items-center justify-center py-4">
            <Upload className="h-12 w-12 text-indigo-500 mb-4" />
            <p className="text-lg font-medium text-gray-700 dark:text-gray-300">
              {isDragActive ? 'Drop the file here' : 'Drag & drop your file here'}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              or click to browse files
            </p>
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-4">
              Supports JPG, PNG, MP4 up to 100MB
            </p>
          </div>
        </div>
      ) : (
        <div className="border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Selected File</h3>
            <button
              onClick={clearSelectedFile}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-full md:w-1/3 bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden flex items-center justify-center" style={{ height: '160px' }}>
              {preview ? (
                <img src={preview} alt="Preview" className="w-full h-full object-contain" />
              ) : (
                <div className="flex flex-col items-center justify-center p-4">
                  {file.type.startsWith('image/') ? (
                    <Image className="h-10 w-10 text-gray-500 dark:text-gray-400" />
                  ) : file.type === 'video/mp4' ? (
                    <Video className="h-10 w-10 text-gray-500 dark:text-gray-400" />
                  ) : (
                    <File className="h-10 w-10 text-gray-500 dark:text-gray-400" />
                  )}
                  <span className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                    {file.type.split('/')[0]}
                  </span>
                </div>
              )}
            </div>
            
            <div className="w-full md:w-2/3">
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">File name</p>
                  <p className="text-gray-900 dark:text-white font-medium truncate">{file.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">File size</p>
                  <p className="text-gray-900 dark:text-white font-medium">
                    {(file.size / (1024 * 1024)).toFixed(2)} MB
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">File type</p>
                  <p className="text-gray-900 dark:text-white font-medium">{file.type}</p>
                </div>
              </div>
            </div>
          </div>
          
          {uploading && (
            <div className="mt-6">
              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-1">
                <span>Uploading...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-indigo-600 h-2 rounded-full transition-all duration-300 ease-in-out"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
            </div>
          )}
          
          <div className="mt-6">
            <button
              onClick={handleUpload}
              disabled={uploading || (currentPlan === 'free' && remainingUploads <= 0)}
              className="w-full btn btn-primary"
            >
              {uploading ? (
                <span className="flex items-center justify-center">
                  <Loader className="animate-spin h-5 w-5 mr-2" />
                  Uploading...
                </span>
              ) : (
                'Upload and Generate'
              )}
            </button>
            
            {currentPlan === 'free' && remainingUploads <= 0 && (
              <p className="mt-2 text-center text-sm text-red-500">
                You've reached your monthly upload limit. <Link to="/plans" className="font-medium underline">Upgrade to Pro</Link> for unlimited uploads.
              </p>
            )}
          </div>
        </div>
      )}
      
      <div className="mt-8 bg-gray-50 dark:bg-gray-900 p-4 rounded-md">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-3">What happens next?</h3>
        <ol className="list-decimal list-inside space-y-2 text-gray-600 dark:text-gray-400">
          <li>Your file will be securely uploaded to our servers</li>
          <li>Our AI will analyze the content and generate captions</li>
          <li>You'll get a short caption, relevant hashtags, and SEO description</li>
          <li>Everything will be saved to your account for future reference</li>
        </ol>
      </div>
    </div>
  );
};

export default UploadForm;