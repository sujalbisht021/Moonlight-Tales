import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';
import { toast } from 'react-toastify';

export type PlanType = 'lite' | 'pro';

type SubscriptionContextType = {
  currentPlan: PlanType;
  isLoading: boolean;
  remainingUploads: number;
  upgradeSubscription: (planType: PlanType) => Promise<void>;
  refreshSubscription: () => Promise<void>;
};

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};

const PLAN_LIMITS = {
  lite: 10,
  pro: 100,
};

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [currentPlan, setCurrentPlan] = useState<PlanType>('lite');
  const [isLoading, setIsLoading] = useState(true);
  const [remainingUploads, setRemainingUploads] = useState(PLAN_LIMITS.lite);

  const fetchSubscriptionInfo = async () => {
    if (!user) {
      setCurrentPlan('lite');
      setRemainingUploads(PLAN_LIMITS.lite);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    
    try {
      // Get subscription info
      const { data: subscriptionData, error: subscriptionError } = await supabase
        .from('subscriptions')
        .select('plan_type, current_period_end')
        .eq('user_id', user.id)
        .single();

      if (subscriptionError && subscriptionError.code !== 'PGRST116') {
        console.error('Error fetching subscription:', subscriptionError);
        throw subscriptionError;
      }

      // Get uploads count
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('uploads_count')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;

      // Determine plan and remaining uploads
      const plan = subscriptionData?.plan_type || 'lite';
      const uploadsCount = profileData?.uploads_count || 0;
      const planLimit = PLAN_LIMITS[plan as PlanType];
      
      setCurrentPlan(plan as PlanType);
      setRemainingUploads(Math.max(0, planLimit - uploadsCount));
    } catch (error) {
      console.error('Error fetching subscription data:', error);
      setCurrentPlan('lite');
      setRemainingUploads(PLAN_LIMITS.lite);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSubscriptionInfo();
  }, [user]);

  const upgradeSubscription = async (planType: PlanType) => {
    if (!user) return;
    
    setIsLoading(true);
    
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          planType,
          userId: user.id,
        }),
      });

      const { url, error } = await response.json();
      
      if (error) throw new Error(error);
      if (!url) throw new Error('No checkout URL returned');

      // Redirect to Stripe Checkout
      window.location.href = url;
    } catch (error) {
      console.error('Error upgrading subscription:', error);
      toast.error('Failed to start checkout process. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const refreshSubscription = fetchSubscriptionInfo;

  const value = {
    currentPlan,
    isLoading,
    remainingUploads,
    upgradeSubscription,
    refreshSubscription,
  };

  return <SubscriptionContext.Provider value={value}>{children}</SubscriptionContext.Provider>;
};